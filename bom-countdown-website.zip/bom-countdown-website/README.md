# 💣 Bomb Countdown Website (Visual Simulator)

Project website bertema **Bomb Countdown Simulator**.
⚠️ Ini hanya simulasi visual countdown untuk tujuan belajar coding dan efek animasi.

## ✨ Fitur
- Countdown interaktif
- Tombol Start & Reset
- Efek visual tema merah gelap

## 🚀 Cara Menjalankan
1. Download file zip
2. Extract
3. Buka `index.html` di browser

## 📂 Struktur File
- index.html
- style.css
- script.js
- README.md

Cocok untuk latihan JavaScript dasar dan DOM manipulation.
