let countdown;
let timeLeft = 10;

const timerElement = document.getElementById("timer");
const statusElement = document.getElementById("status");

function startCountdown() {
    statusElement.textContent = "Countdown dimulai...";
    clearInterval(countdown);

    countdown = setInterval(() => {
        timeLeft--;
        timerElement.textContent = timeLeft;

        if (timeLeft <= 0) {
            clearInterval(countdown);
            timerElement.textContent = "💥";
            statusElement.textContent = "Boom! (Simulasi selesai)";
        }
    }, 1000);
}

function resetCountdown() {
    clearInterval(countdown);
    timeLeft = 10;
    timerElement.textContent = timeLeft;
    statusElement.textContent = "Countdown direset.";
}
